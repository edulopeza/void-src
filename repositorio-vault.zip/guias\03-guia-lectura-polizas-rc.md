# Guia 03 - Como leer una poliza de RC y detectar exclusiones

## Para que sirve esta guia

Una poliza de Responsabilidad Civil de eventos NO es un documento que firmas y archivas. Es un contrato que tiene clausulas, exclusiones, capitales y sublimites que pueden dejarte SIN cobertura el dia que la necesitas.

Esta guia te explica como leerla criticamente, seccionar por seccionar, para detectar los agujeros antes de que sea demasiado tarde.

## Antes de firmar la poliza

Solicita a tu mediador o broker tres documentos:

1. **Condiciones generales**: el texto completo de la poliza tipo.
2. **Condiciones particulares**: lo que se aplica especificamente a tu poliza.
3. **Anexo de coberturas expresas**: lo que has contratado como extension (pirotecnia, UAS, atracciones, defensa penal, etc.).

Los tres son necesarios. Las condiciones generales sin las particulares no dicen nada concreto. Las particulares sin las generales dejan sin regular las lagunas. El anexo sin las dos anteriores es solo un compromiso verbal.

## Seccion por seccion: que mirar

### 1. Datos del tomador y del asegurado

Verifica que el nombre fiscal del promotor (no el nombre comercial) coincide exactamente con el de tu empresa. Si el Tomador es una persona fisica y el Asegurado es una SL, los siniestros pueden quedar fuera.

### 2. Objeto del seguro

Tiene que decir literalmente algo como: Cobertura de la Responsabilidad Civil extracontractual en que pueda incurrir el Asegurado por danos y perjuicios causados a terceros como consecuencia de la organizacion y celebracion de la actividad declarada (concierto / festival / evento / espectaculo publico).

Si dice otra cosa o es ambiguo, pidele a tu mediador que reformule. El lenguaje vago en la poliza es donde se pierden los juicios.

### 3. Ambito geografico y temporal

- **Territorial**: que diga expresamente Espana (o tu CCAA) y, si haces giras, que cubra la Union Europea.
- **Temporal**: que cubra la fecha y horario de tu evento. Verifica que no hay periodo de carencia.
- **Actividad declarada**: tiene que coincidir exactamente con la de tu autorizacion municipal.

### 4. Suma asegurada por siniestro y por anualidad

Aqui estan los numeros que importan. No te quedes en la cifra grande de la portada. Mira:

| Concepto | Capital tipico | Verificacion |
|---|---|---|
| RC general por siniestro | 600.000-3.000.000 EUR | ¿Es suficiente para tu aforo? Madrid Arena necesito >1.750.000 EUR solo en indemnizaciones. |
| RC general por anualidad | 1.500.000-5.000.000 EUR | ¿Cubres todos tus eventos del ano? |
| Sublimite por victima | 150.000-300.000 EUR | Verifica que el sublimite por victima NO sea inferior al capital total. Madrid Arena necesito 350.000 EUR por familia. |
| Defensa penal | 30.000-60.000 EUR | Verifica que esta incluida. NO esta por defecto. |
| Fianza judicial | 30.000-60.000 EUR | Verifica que esta incluida. NO esta por defecto. |
| Franquicia | 0-3.000 EUR | Cuanto mayor la franquicia, menor la prima, pero mayor tu riesgo. |

### 5. Exclusiones

Aqui esta la zona caliente. Lee TODO el apartado de exclusiones. No te fies de tu broker. Las exclusiones habituales en polizas de espectaculos son:

- **Pirotecnia T2**: excluida por defecto. Necesitas anexo especifico. Verifica que el anexo nombra T2, no solo T1.
- **UAS / drones**: excluido por defecto. Necesitas anexo especifico para operacion en categoria Especifica.
- **Laser clase 3B y 4**: a veces excluido. Verifica.
- **Hazer / humo artificial**: algunas polizas lo excluyen si causa dano respiratorio.
- **Aforo superior al declarado**: si vendes mas entradas de las declaradas en la poliza, TODA la cobertura cae. Mira el caso Madrid Arena.
- **Personal sin alta en la Seguridad Social**: si hay accidente laboral con persona en B, exclusion.
- **Subcontratas sin seguro verificado**: si una subcontrata falla, el promotor responde solidariamente.
- **Terrorismo**: excluido por defecto. Necesitas ampliacion especifica.
- **Pandemias / DANA / fuerza mayor**: excluido en muchas polizas desde 2020. Necesitas clausula especifica.
- **Sanciones administrativas**: las multas NO son asegurables (principio legal).
- **Dolo o imprudencia temeraria**: excluido por ley. La imprudencia grave SI esta cubierta. La temeraria no.

### 6. Coberturas adicionales (anexos)

Los anexos son opcionales y tienen coste extra. Verifica que los que necesitas estan en la poliza:

| Anexo | Coste orientativo | Para que sirve |
|---|---|---|
| Pirotecnia T2 | 200-500 EUR por evento | Si usas cold sparks, bengalas T2, fuentes pirotecnicas |
| UAS categoria Especifica | 200-600 EUR por evento | Si tienes show de drones |
| Defensa penal | incluida o extension 100-200 EUR | Si hay imputacion penal al promotor |
| Fuerza mayor con AEMET | variable | Si cubres suspension por alerta naranja/roja AEMET |
| Terrorismo | variable | Si el evento es susceptible |
| Atracciones de feria | 200-500 EUR | Si tienes norias, hinchables, carruseles dentro del recinto |
| Lazer 3B/4 | 100-300 EUR | Si tienes show laser |
| Equipos electricos y montajes | incluida o 100-300 EUR | Si tienes generadores, cerchas, escenarios |

### 7. Siniestros: plazo y procedimiento

- **Plazo de comunicacion**: tipicamente 24-72 horas. No te enteres un lunes de un siniestro del sabado.
- **Forma de comunicacion**: telefono 24h (en la poliza) + correo o plataforma digital.
- **Documentacion obligatoria**: parte de accidente, fotos, partes de asistencia, declaracion del asegurado.
- **Perito de la aseguradora**: suele venir al dia siguiente. NO toques la escena del accidente hasta que llegue o hasta que te diga que puedes.

### 8. Cláusulas de rescision y de no renovacion

- **Periodo de preaviso**: si cancelas, cuanto tiempo antes tienes que avisar (tipicamente 1 mes).
- **No renovacion**: la aseguradora puede no renovar a la vuelta. Te interesa saberlo con tiempo.
- **Rescision por siniestro**: en algunos casos, tras un siniestro grave, la aseguradora puede dar de baja la poliza. Esto es legal y debes saberlo.

## Checklist rapido de lectura critica

Antes de firmar la poliza, verifica:

- [ ] El nombre del tomador y del asegurado coincide con tu empresa
- [ ] La actividad declarada coincide con la de tu autorizacion
- [ ] La suma asegurada por siniestro es mayor que 2 x indemnizacion esperada del peor caso
- [ ] El sublimite por victima NO es inferior al capital total
- [ ] NO hay exclusion por pirotecnia T2 (o hay anexo que la cubre)
- [ ] NO hay exclusion por UAS (o hay anexo)
- [ ] NO hay exclusion por aforo superior al declarado
- [ ] La defensa penal esta incluida
- [ ] La fianza judicial esta incluida
- [ ] El plazo de comunicacion de siniestro es compatible con tu operativa
- [ ] El periodo de preaviso de no renovacion es razonable

## Cuando la poliza NO es suficiente

Si tras la lectura critica detectas que tu poliza tiene exclusiones criticas no cubiertas por anexos:

1. **Renegocia con la aseguradora**: a veces, ampliar un anexo cuesta 200-500 EUR. Compáralo con el coste de un siniestro.
2. **Cambia de aseguradora**: hay aseguradoras especializadas en espectaculos publicos que tienen mejor cobertura que las generalistas. Brokers como AON, Marsh, Howden o Willis tienen divisiones especializadas.
3. **Asume el riesgo**: si el riesgo es pequeño y el coste del anexo es desproporcionado, documenta la decision y asume la responsabilidad (con PAU bien hecho, el riesgo es menor).

---

## Caso real: el cierre por exclusiones que dejo a un promotor sin cobertura

Festival de musica en zona rural, aforo 4.000 personas, poliza de RC generalista 600.000 EUR. Tuvo un accidente: una estructura de escenario colapso por viento y un espectador sufrio lesiones graves.

La aseguradora denego la cobertura por tres exclusiones acumuladas:

1. La estructura del escenario no estaba expresamente incluida (excluida en poliza general).
2. El aforo vendido (4.200 entradas) superaba el aforo declarado en la poliza (3.500) en un 20%.
3. El viento que tumbó la estructura era de 75 km/h, que la aseguradora califico de fenomeno meteorologico previsible, excluido de la cobertura de fuerza mayor.

El promotor tuvo que responder con patrimonio personal: alrededor de 800.000 EUR entre indemnizacion al lesionado, costas procesales y defensa juridica. La poliza de 600.000 EUR no pago un solo euro.

El promotor, que habia pagado 4.200 EUR de prima anual, perdio su casa.

Esa noche, si hubiera leido esta guia, habria visto las tres banderas rojas y o habia renegociado o no habria firmado.

---

(C) 2026 Eduardo J. Lopez A.
Licencia CC BY-NC 4.0
