# Indice de Guias Operativas

Las plantillas del Repositorio son documentos rellenables. Las guias son la metodologia que necesitas para usarlas bien, sin perder tiempo ni firmar a ciegas.

| # | Guia | Formato | Para que sirve |
|---|------|---------|----------------|
| 01 | Como usar la calculadora de aforo | .md | Paso a paso para rellenar la plantilla 12 sin meter la pata |
| 02 | A quien preguntar que | .md | Directorio operativo: que preguntar al Ayuntamiento, a la CCAA, a AESA, al 112, etc. |
| 03 | Como leer una poliza de RC y detectar exclusiones | .md | Checklist de lectura critica de la poliza de seguro del evento |
| 04 | Que plantilla uso para cada tipo de evento | .md | Mapa de decision segun tipo de actividad, aforo y CCAA |
| 05 | Cumplimiento por CCAA | .md | Matriz resumen de particularidades autonomicas que afectan a las plantillas |
| 06 | Gatillos automaticos: cuando suspender | .md | Cuando parar preventivamente por meteorologia, aforo, avalancha, etc. |

## Como usar este conjunto de guias

1. Antes de un evento nuevo, lee la Guia 04 (que plantilla uso) para identificar que documentos necesitas.
2. Antes de firmar el contrato con la aseguradora, lee la Guia 03 (lectura de polizas) y aplica el checklist.
3. Antes de imprimir la documentacion para presentar al Ayuntamiento, revisa la Guia 05 (cumplimiento CCAA) por si tu comunidad tiene particularidades.
4. El dia del evento, ten a mano la Guia 06 (gatillos automaticos) en el puesto del Director del PAU.
5. Despues del evento, archiva la documentacion siguiendo la Guia 02 (contactologia).

## Aviso

Las guias son orientacion operativa, NO sustituyen al asesoramiento juridico de un abogado especializado en espectaculos publicos, ni al PAU firmado por un tecnico competente. Antes de presentar documentacion critica, valida con tu abogado y con tu tecnico.

(C) 2026 Eduardo J. Lopez A.
Manual de Seguridad, Prevencion y Planes de Autoproteccion en Eventos y Espectaculos
Licencia CC BY-NC 4.0
