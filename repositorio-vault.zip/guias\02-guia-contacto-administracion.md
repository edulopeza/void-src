# Guia 02 - A quien preguntar que (directorio operativo)

## Para que sirve esta guia

Cuando tienes una duda operativa, no sabes a quien llamar. Esta guia te dice, organizacion por organizacion, que tipo de preguntas les puedes hacer y que NO les puedes preguntar.

## Regla de oro: empieza por abajo y sube

1. **Ayuntamiento** (Junta Municipal de Distrito, Concejalía de Fiestas, Concejalía de Actividades) para casi todo lo local.
2. **Comunidad Autonoma** (Consejeria de Cultura, Interior, Presidencia) si la materia es competencia transferida.
3. **Delegacion del Gobierno / Subdelegacion** para pirotecnia, armas, UAS (drones).
4. **AESA** (Agencia Estatal de Seguridad Aerea) para drones especificos.
5. **Mutua / Servicio de Prevencion** para riesgos laborales.
6. **Aseguradora** para polizas y exclusiones.
7. **Abogado** cuando hay litigio o interpretacion juridica.

No empieces por arriba. Si preguntas a AESA por una licencia municipal, no te van a contestar. Si preguntas al Ayuntamiento por la categoria operativa de un dron, tampoco.

---

## Ayuntamiento (Junta Municipal / Concejalía de Actividades / Fiestas)

### Que SI preguntar

- Licencia de actividad del local o del evento.
- Autorizacion municipal para ocupacion de via publica.
- Autorizacion para cruce de cable en via publica.
- Autorizacion para amplificacion de sonido (limites acusticos municipales).
- Cortes de trafico.
- Aforo legal del recinto.
- Informe del tecnico municipal sobre requisitos especificos.
- Quién es el tecnico de actividades asignado a tu zona.

### Que NO preguntar

- Categoria operativa UAS (eso es AESA).
- Autorizacion para pirotecnia F3 o F4 (eso es Subdelegacion del Gobierno / Intervencion de Armas).
- Normativa estatal supletoria.
- Si el PAU cumple RD 393/2007 o RD 524/2023 (eso es el tecnico competente, no el Ayuntamiento).
- Aforo legal de un local si no tienes la licencia (el Ayuntamiento te dira que pidas cita con el tecnico).

### Telefonos / canales habituales

- Sede electronica del Ayuntamiento (primera opcion).
- Telefono 010 (en Madrid, Barcelona, Valencia, etc.).
- Junta Municipal de Distrito (en ciudades grandes con distritos).
- Concejalía de Fiestas o de Cultura en municipios pequenos.

---

## Comunidad Autonoma (Consejeria competente)

### Que SI preguntar

- Si el evento cruza mas de un municipio (la autorizacion es autonoma, no municipal).
- Aplicacion de la ley de espectaculos autonoma (Galicia, Madrid, Cataluña, Valencia, Andalucia, Aragon, etc.).
- Regimen de horarios especificos por CCAA.
- Servicio de inspeccion autonomica de espectaculos.
- Registro de empresas de seguridad privada (en la mayoria de CCAA).
- Registro de empresas pirotécnicas (en la mayoria de CCAA).
- Catalogo de espectaculos publico, actividades recreativas y establecimientos abiertos al publico.

### Que NO preguntar

- Licencias municipales (es competencia del Ayuntamiento).
- Cuestiones de la empresa de seguridad privada a nivel de habilitacion nacional (es la Subdelegacion del Gobierno).
- UAS (es AESA).
- Si la pirotecnia T1, T2, F3, F4 cumple la norma tecnica (es el fabricante con marcado CE).

### Telefonos / canales

- Sede electronica de la CCAA.
- Direccion General competente en espectaculos publicos.
- Consejeria de Cultura, Interior, Presidencia (depende de la CCAA).

---

## Subdelegacion del Gobierno / Intervencion de Armas (Guardia Civil)

### Que SI preguntar

- Autorizacion para pirotecnia F3 y F4 (catalogo + seguro + proyecto).
- Comunicacion de pirotecnia T1 y T2 con catalogo.
- Tramitacion de personal con carnet de artillero pirotécnico.
- Registro de empresas pirotécnicas (Intervencion Central de Armas y Explosivos).
- Autorizacion de espectaculos publicos en zonas de competencia estatal (cuando aplique).

### Que NO preguntar

- Licencias municipales o autonomicas.
- Si la pirotecnia cumple la norma UNE o la directiva europea (es el fabricante con marcado CE, no la Guardia Civil).
- Recomendaciones tecnicas de uso (eso es el tecnico competente o el fabricante).

### Telefonos / canales

- Subdelegacion del Gobierno en cada provincia.
- Intervencion de Armas y Explosivos de la Guardia Civil (ICAE).
- Para pirotecnia: Seccion de Armas y Explosivos de la Comandancia de la Guardia Civil.

---

## AESA (Agencia Estatal de Seguridad Aerea)

### Que SI preguntar

- Registro de operador UAS.
- Categoria operativa aplicable a tu operacion (Abierta, Especifica, Certificada).
- Si tu operacion con drones puede acogerse a un STS-ES-NE.
- Autorizacion caso por caso para operaciones en categoria Especifica.
- Requisitos del piloto UAS (A1/A3, A2, LSTS, etc.).
- Notificacion de incidente con UAS.

### Que NO preguntar

- Si tu evento requiere autorizacion municipal (eso es el Ayuntamiento).
- Si la pirotecnia de los drones es legal (eso es Subdelegacion del Gobierno).
- Como volar los drones (eso es formacion del piloto).
- Seguros especificos (eso es la aseguradora del operador UAS).

### Telefonos / canales

- Sede electronica de AESA: https://www.seguridadaerea.gob.es
- Buzon de consultas UAS.

---

## Mutua de Accidentes de Trabajo / Servicio de Prevencion

### Que SI preguntar

- Cobertura del personal de produccion en caso de accidente laboral.
- Reconocimiento medico del personal.
- Formacion PRL especifica para el puesto.
- Cobertura de los voluntarios o personal en practicas.
- Procedimiento de comunicacion de accidente laboral (parte de accidente, baja, etc.).

### Que NO preguntar

- Si el personal esta dado de alta en la Seguridad Social (eso es la TGSS).
- El coste de la mutua (eso lo negocia el empleador con la mutua).
- Las sanciones de la Inspeccion de Trabajo (eso es la ITSS).

### Telefonos / canales

- Mutua del empleador (FREMAP, MUTUA UNIVERSAL, ASEPEYO, etc.).
- Servicio de Prevencion Ajeno o Propio de la empresa promotora.

---

## Aseguradora del evento

### Que SI preguntar

- Cobertura especifica de pirotecnia T2, UAS, atracciones de feria, etc.
- Exclusiones concretas de la poliza (clausula por clausula).
- Suma asegurada (capital de RC, franquicia, sublimites).
- Cobertura de defensa penal (incluida o como extension).
- Cobertura de fuerza mayor (alerta AEMET naranja/roja, pandemia, atentado).
- Siniestro: como y cuando comunicarlo (plazos, telefono 24h, documentacion).

### Que NO preguntar

- Si la actividad es legal (eso es tu abogado).
- Si la documentacion del evento cumple la normativa (eso es el tecnico competente).
- Si el Ayuntamiento te va a dar la licencia (eso es el Ayuntamiento).
- La calificacion del siniestro en un juicio (eso es tu abogado y el juez).

### Telefonos / canales

- Tu mediador o broker de seguros.
- Telefono de atencion 24h de la aseguradora (suele estar en la poliza).

---

## Hospital de referencia / 061 / 112

### Que SI preguntar al hospital concertado

- Capacidad de derivacion (UCI, urgencias, traumatologia).
- Tiempo estimado de derivacion desde el recinto.
- Protocolo de aviso previo.
- Persona de contacto en el servicio de urgencias.

### Que SI preguntar al 061 / 112

- Estado operativo de los servicios de emergencia.
- Estado de la via publica (cortes, accidentes, manifestaciones).
- Activacion del Plan de Proteccion Civil (inundaciones, incendio, etc.).
- Coordinacion entre servicios.

### Que NO preguntar

- Si un paciente concreto puede ir a un hospital (decision medica, no del 112).
- Si un evento es legal (no es competencia del 112).
- El aforo del recinto (no es competencia del 112).

### Telefonos / canales

- 112 (emergencias, las 24 horas).
- 061 (sanidad, varias CCAA).
- Hospital concertado: el de tu eleccion, con pacto previo de derivacion firmado (plantilla 06).

---

## Abogado especializado en espectaculos

### Que SI preguntar

- Interpretacion juridica de la normativa aplicable.
- Redaccion de contratos con artistas, subcontratas, recintos.
- Reclamaciones de asistentes, artistas o proveedores.
- Defensa ante inspecciones, sanciones o juicios.
- Clausulado de la poliza de seguro.

### Que NO preguntar

- Normativa tecnica (eso es el tecnico competente, no el abogado).
- Calculo de aforo (eso es la calculadora, con supervision del tecnico).
- Como montar el escenario (eso es el ingeniero de montaje).

### Telefonos / canales

- Bufete especializado (mejor uno con experiencia en derecho administrativo + derecho de seguros + derecho laboral).
- Colegio de Abogados de tu provincia.

---

## Resumen: el orden de las llamadas

1. **Duda sobre aforo, licencia municipal, ocupacion de via publica, ruido**: Ayuntamiento.
2. **Duda sobre ley de espectaculos de tu CCAA, registro autonomico, horarios**: Consejeria autonoma.
3. **Duda sobre pirotecnia F3, F4, artilleros, armas**: Subdelegacion del Gobierno / Intervencion de Armas.
4. **Duda sobre drones, registro UAS, categoria operativa**: AESA.
5. **Duda sobre la poliza, exclusion, siniestro**: Aseguradora (antes) y Abogado (si hay conflicto).
6. **Duda sobre accidente laboral, alta en Seguridad Social, formacion PRL**: Mutua o Servicio de Prevencion.
7. **Duda sobre la normativa tecnica, calculo estructural, validacion del PAU**: Tecnico competente (ingeniero, arquitecto, T.S. en PRL con experiencia en eventos).

---

## Regla final: la trazabilidad

Todas las conversaciones importantes (consultas a Ayuntamiento, AESA, aseguradora, etc.) deberian quedar documentadas por escrito. Si llamas por telefono, manda despues un correo electronico confirmando lo hablado. Si acudes a una reunion, pide un acta firmada por ambas partes.

Esa documentacion es la que te salva si un dia hay inspeccion, siniestro o juicio.

---

(C) 2026 Eduardo J. Lopez A.
Licencia CC BY-NC 4.0
