# Guia 06 - Gatillos automaticos: cuando suspender un evento

## Para que sirve esta guia

El momento de decidir si un evento sigue, se suspende temporalmente o se cancela definitamente es el momento de mayor responsabilidad del Director del PAU. Una decision tardia puede costar vidas (Medusa Cullera 2022, cuatro muertas por una rafaga de viento que ya estaba prevista). Una decision prematura puede costar el evento entero y una reclamacion de danos del promotor contra el Director.

Esta guia establece **gatillosAutomaticos**: parametros objetivos, medibles, con fuentes oficiales, que disparan la suspension sin que intervenga la discrecionalidad. Cuando se cumple un gatillo, el Director del PAU NO delibera: aplica el protocolo. Esto blinda al Director juridicamente y reduce la improvisacion.

Los gatillosAutomaticos son parametros, no opiniones. La ley no exige que el Director sea infalible: exige que aplique criterios tecnicos objetivos. Esta guia te da esos criterios.

---

## Bloque 1 - Gatillos meteorologicos

### 1.1 Viento

#### Umbral de suspension

- **Aire libre sin escenario con estructuras rigidas**: suspender preventivamente con rafagas sostenidas (no rachas puntuales) por encima de **40 km/h** durante mas de 10 minutos consecutivos, segun lectura de anemometro calibrado en el recinto.
- **Aire libre con escenario / gradas / backline / estructuras temporales (carpas, torres, truss, rigging)**: suspender preventivamente con rafagas sostenidas por encima de **30 km/h**. Cualquier estructura temporal en altura multiplica el riesgo por el cuadrado de la altura.
- **Recinto cerrado con ventilacion insuficiente**: revisar aforo y temperatura; el viento en si no es el factor.

#### Fuentes para aplicar el gatillo

- **Anemometro del recinto**: fuente principal. Colocarlo a 10 metros de altura, sin obstaculos, calibrado al inicio de la jornada.
- **AEMET**: fuente complementaria. La prediccion por municipios a 7 dias es orientativa; el parte a 24 horas es vinculante. Ignora los partes de apps gratuitas.
- **Servicio de asesoramiento meteorologico privado** (MeteoGroup, Meteosim, etc.): si el evento es suficientemente importante como para contratar uno, su lectura prevalece sobre la del anemometro propio.

#### Caso ancla: Medusa Sun Beach Festival (Cullera, Valencia, 13-agosto-2022). Cuatro asistentes muertas y decenas de ciega por una rafaga de viento que arranco parte de la estructura del escenario. AEMET habia activado el aviso naranja por viento (rafagas de hasta 80 km/h). El festival continuo hasta que el escenario colapso. Caso en instruccion judicial.

**Leccion**: no se suspende cuando el escenario cae; se suspende cuando el anemometro marca el umbral. Cuando AEMET emite aviso naranja, se activa el pre-aviso: se monitoriza cada 5 minutos en lugar de cada 30.

#### Procedimiento operativo

1. Anemometro colocado y calibrado antes de la apertura.
3. Lectura registrada cada 30 minutos en el parte de PAU (Plantilla 03 pau-express).
3. Si se supera 30 km/h sostenido: avisar al equipo de escenario (jefe de rigging).
4. Si se supera 40 km/h sostenido: aviso al publico por megafonia: "por condiciones meteorologicas adversas, les pedimos que se retiren temporalmente de las zonas elevadas".
5. Si se supera 50 km/h sostenido: suspension del espectaculo. Evacuacion ordenada de las zonas de riesgo (gradas, torres, zonas altas de escenario).

### 1.2 Lluvia

#### Umbral de suspension

- **Lluvia ligera (<5 mm/h)**: el evento continua con monitorizacion reforzada.
- **Lluvia moderada (5-15 mm/h)**: el evento continua si hay zonas cubiertas para equipo y publico. Si no las hay, suspension temporal.
- **Lluvia fuerte (>15 mm/h)**: suspension temporal. Superficies deslizantes, sistemas electricos comprometidos, visibilidad reducida.
- **Tormenta electrica**: suspension total e inmediata.

#### Caso ancla: Boombastic Asturias (Llanera, agosto-2024). Cierre temporal del recinto por tormenta con 15.000 asistentes. La organizacion activo el protocolo: 30 minutos antes de la tormenta, megafonia avisando, evacuacion ordenada de zonas abiertas hacia zonas cubiertas. Cero incidentes. Caso en investigacion por otros motivos, pero la gestion meteorologica fue correcta.

#### Procedimiento operativo

1. Radar meteorologico consultado en intervalo de 15 minutos durante el evento.
2. Si la tormenta esta a menos de 20 km del recinto: pre-aviso a produccion y seguridad.
3. Si la tormenta esta a menos de 10 km: megafonia preventiva al publico.
4. Si la tormenta esta a menos de 5 km o se detecta aparato electrico: suspension total, publico trasladado a zonas cubiertas o evacuado.

### 1.3 Rayos (actividad electrica)

#### Umbral de suspension

- **Riesgo bajo**: 0-10 rayos detectados a menos de 16 km en los ultimos 30 minutos. El evento puede continuar.
- **Riesgo elevado**: mas de 10 rayos en 30 minutos a menos de 16 km. Suspension temporal.
- **Riesgo extremo**: 1 o mas rayos a menos de 8 km. Suspension total y evacuacion.

#### Fuentes para aplicar el gatillo

- **Detector de rayos local**: si el evento es grande, instalar uno propio.
- **AEMET / Meteoexploration**: parte de actividad electrica.
- **Aplicaciones profesionales**: Blitzortung, NowCast.

#### Regla de los 30/30

Si ves un rayo, cuenta los segundos hasta el trueno. Divide por 3 para obtener la distancia en kilometros. Si la distancia es menor de 8 km, no reanudes hasta que hayan pasado 30 minutos sin rayos a menos de 8 km.

### 1.4 Temperatura extrema

#### Umbral de suspension

- **Temperatura maxima prevista superior a 40 grados centigrados** (o 35 si hay humedad relativa superior al 60 %): suspension preventiva del espectaculo del mediodia, hidratacion reforzada, sombras obligatorias.
- **Indice de calor WBGT superior a 32 grados**: reduccion de actividad fisica intensa, hidratacion obligatoria cada 20 minutos.
- **Temperatura minima prevista inferior a 0 grados centigrados** con viento: suspension preventiva por riesgo de hipotermia (concurrencias en exteriores de larga duracion).

#### Procedimiento operativo

1. Termometro de globo y bulbo humedo (WBGT) en zona de publico y en zona de personal.
2. Puntos de hidratacion accesibles y señalizados (minimo 1 por cada 500 personas).
3. Zonas de sombra o calefaccion segun estacion.
4. Personal con formacion en golpes de calor y hipotermia.

---

## Bloque 2 - Gatillos de aforo y densidad

### 2.1 Densidad maxima

#### Umbrales (referencia Madrid OLDRUAM 6/2022 y estatal RGPE)

- **4 personas por metro cuadrado en aire libre**: es el estandar del Estado. A partir de ahi, el riesgo de avalancha se multiplica.
- **2 personas por metro cuadrado en recinto cerrado**: referencia para aforo legal maximo.

#### GatilloAutomatico

- Densidad instantanea **superior a 6 personas por metro cuadrado en cualquier zona del recinto** durante mas de 5 minutos: suspension temporal. Apertura de vias de evacuacion, redireccion del flujo.
- Densidad **superior a 8 personas por metro cuadrado**: suspension total.

#### Como medirlo

- Conteo manual con ceros manuales en puntos de aforo.
- CCTV con inteligencia artificial de (si se dispone).
- Drones de vigilancia (con autorizacion AESA, categoria especifica).
- Estimacion por ratios de barras de bebida, tiempo de espera en servicios, velocidad de evacuacion del recinto.

#### Caso ancla: Madrid Arena (Madrid, 1-noviembre-2012). Cinco muertas, una lesionada medular permanente. Aforo legal: 10.620 personas. Entradas vendidas: 16.605 personas. Densidad estimada en la pista: 8-9 personas por metro cuadrado. Condena de 4 años de prision al promotor por homicidio imprudente (TS 805/2017).

**Leccion**: el aforo no es orientacion. Si tienes sobre 4 personas/m2 en aire libre, no es un "evento lleno": es un evento inseguro. La responsabilidad penal del Director del PAU es personal, no de la empresa.

### 2.2 Tiempo de espera en servicios

#### GatilloAutomatico

- Tiempo de espera medio para acceder al servicio **superior a 15 minutos**: alerta amarilla.
- Tiempo de espera medio **superior a 30 minutos**: alerta naranja. Suspension temporal de espectaculo (musica en directo) para redistribuir gente.
- Tiempo de espera medio **superior a 45 minutos**: alerta roja. Suspension total.

#### Justificacion

La gente que espera en colas de servicio se acumula en zonas pequenas. Si la cola es de mas de 45 minutos, la densidad en la cola es mayor que en la zona de barras. Es una trampa mortal invisible.

### 2.3 Avalancha / estampida (precursores)

#### Senales de aviso

- **Presion fisica multidireccional** en una zona: la gente no puede caminar libremente.
- **Sonido caracteristico de jadeo colectivo** (respiracion agitada de muchas personas).
- **Movimientos involuntarios**: la gente empieza a ser empujada sin querer moverse.
- **Caidas aisladas**: alguien cae y no puede levantarse porque los demas no pueden esquivarlo.
- **Tambaleo**: el grupo se mueve como una ola.

#### GatilloAutomatico

Ante cualquier senal: **suspension inmediata**. Apertura de vias de evacuacion. Detener espectaculo. Reducir iluminacion (para que el publico deje de mirar al escenario y busque salidas). Comunicacion por megafonia: "por motivos de seguridad, les pedimos que se dirijan a las salidas laterales".

#### Caso ancla: Festival de Roskilde (Dinamarca, 2000). Nueve muertas en avalancha durante concierto de Pearl Jam. Densidad estimada: 10 personas/m2. El publico empezo a caer en dominada. La reja de seguridad que separaba escenario y publico impidio la dispersion. Caso que impulso la legislacion danesa de eventos masivos.

---

## Bloque 3 - Gatillos estructurales

### 3.1 Fallo de escenario / estructura

#### GatilloAutomatico

- **Deformacion visible** de cualquier estructura (truss, backline, carpa, grada, valla, escenario, torre): suspension inmediata y evacuacion de la zona.
- **Sonido metalico anormal** (crujido, chasquido, estallido): suspension inmediata.
- **Vibracion excesiva** bajo carga estatica: suspension inmediata.

#### Procedimiento

1. El jefe de rigging o el tecnico de estructuras declara la incidencia.
2. Suspension inmediata del espectaculo.
3. Evacuacion de la zona estructural (minimo el doble de la altura de la estructura).
4. Inspeccion tecnica visual antes de cualquier reanudacion.

### 3.2 Fallo electrico

#### GatilloAutomatico

- **Corte total** superior a 30 segundos: el evento no puede continuar sin iluminacion (seguridad y evacuacion comprometidas).
- **Corte parcial** de un area: evacuacion del area afectada.
- **Averia del sistema de megafonia**: suspension del espectaculo. Sin megafonia no puedes dirigir al publico en caso de emergencia.
- **Averia del sistema de deteccion de incendios**: suspension. Sin deteccion, cualquier conato es invisible.

#### Caso ancla: Festival Pukkelpop (Bélgica, 18-agosto-2011). Cinco muertas por colapso de escenario durante rafaga de viento. La estructura no estaba preparada para el viento registrado. Caso que impulso la revision de la normativa belga y europea sobre escenarios temporales.

### 3.3 Fallo de agua / saneamiento

#### GatilloAutomatico

- **Sin agua potable** en los grifos del publico durante mas de 1 hora: suspension temporal.
- **Sin servicios higienicos** funcionales durante mas de 2 horas: suspension temporal.
- **Inundacion** de cualquier zona del recinto: suspension inmediata y evacuacion.

---

## Bloque 4 - Gatillos de seguridad

### 4.1 Intrusion en zonas restringidas

#### GatilloAutomatico

- **Intrusion en zona de backstage, escenario, FOH, control, deposito de bebida o zona electrica**: suspension temporal del espectaculo. Si la intrusion es multiple o agresiva: suspension total.
- **Intrusion en zona de taquillas o caja fuerte**: suspension temporal y aviso a Fuerzas y Cuerpos de Seguridad.

### 4.2 Agresion, arma o amenaza

#### GatilloAutomatico

- Cualquier agrsion en el recinto: suspension temporal, intervencion del servicio de seguridad, aviso a 112 si hay lesiones.
- Cualquier arma blanca o de fuego detectada: suspension total, aviso inmediato a 112, evacuacion ordenada.
- Cualquier amenaza de bomba o atentado: suspension total, evacuacion siguiendo protocolo antiterrorista (consultar con FCSE).

### 4.3 Sospecha de atentado terrorista

#### Procedimiento

1. Aviso inmediato a 062 (Guardia Civil) o 091 (Policia Nacional).
2. Suspension total.
3. Evacuacion controlada (sin panico) siguiendo el Plan de Evacuacion del PAU.
4. Mantener al publico informado por megafonia: "por motivos de seguridad, les pedimos que abandonen el recinto de forma ordenada por las salidas senalizadas".

#### Caso ancla: Bataclan (Paris, 13-noviembre-2015). 90 muertas en sala de conciertos. Caso que impulso la revision de los protocolos antiterroristas en eventos en toda Europa.

---

## Bloque 5 - Gatillos de autoridad

### 5.1 Orden de suspension por la Administracion

#### Procedimiento

- La autoridad municipal o autonoma puede ordenar la suspension del evento por motivos de seguridad, ruido, aforo o cualquier causa justificada.
- Si la orden llega por escrito (acta, notificacion, resolucion): cumplimiento inmediato. Guardar copia firmada.
- Si la orden llega verbalmente: solicitar confirmacion por escrito. Si la autoridad no la puede emitir por escrito, grabarla (donde sea legal) o documentarla con testigos. Despues de cumplirla, solicitar el escrito retroactivo.

### 5.2 Orden de suspension por FCSE

- Suspension inmediata por orden de Policia Nacional, Guardia Civil o Policia Municipal. Sin discusion. Sin negociacion. La autoridad policial tiene competencia para suspender cualquier espectaculo publico en el ejercicio de sus funciones.

### 5.3 Orden judicial

- Suspension inmediata por orden judicial (juez de instruccion, juez de guardia). Cumplimiento inmediato. Comunicacion al abogado de la empresa en las siguientes 24 horas.

---

## Bloque 6 - Gatillos medicos

### 6.1 Incidencia medica grave

#### GatilloAutomatico

- **Una persona fallecida** en el recinto: suspension total. Comunicacion a 112. Apertura de la investigacion judicial correspondiente. El evento no se reanuda hasta que la autoridad judicial lo autorice.
- **Multiples victimas** (mas de 5 personas atendidas por la misma causa): suspension temporal. Reunion urgente del comite de PAU. Evaluacion de la causa (avalancha, calor, intoxicacion, ataque de panico colectivo).
- **Intoxicacion etilica masiva** (mas de 10 personas atendidas por intoxicacion): suspension temporal. Investigacion de la procedencia del alcohol. Aviso a FCSE.

### 6.2 Incidencia colectiva sin causa aparente

#### GatilloAutomatico

- Si el dispositivo medico atiende a mas de **20 personas en 30 minutos por la misma causa** (mareos, nauseas, dificultad respiratoria, perdida de conciencia): sospecha de foco toxico (gas, agente quimico, contaminacion). Suspension total. Aviso a 112. Activacion de protocolo NRBQ.

---

## Bloque 7 - Quien decide y como se documenta

### 7.1 Quien decide

#### Director del PAU (Director del Plan de Autoproteccion)

Tiene la autoridad final para suspender. Esta autoridad NO puede ser delegada ni cuestionada por el promotor, por el artista, por el productor, ni por el representante del recinto.

Su decision esta protegida legalmente si:
- Esta basada en criterios tecnicos objetivos (esta guia).
- Esta documentada en el parte del PAU (Plantilla 03 pau-express).
- Se aplica de forma proporcional al riesgo.

Su decision NO esta protegida si:
- Es arbitraria o caprichosa.
- Se basa en criterios economicos (no perder dinero) sin causa tecnica.
- Se retrasa de forma evidente frente a un riesgo conocido.

### 7.2 Como se documenta

#### Parte de suspension (Plantilla 03 pau-express)

El parte debe incluir:

1. **Fecha, hora y lugar** de la suspension.
2. **Identificacion del gatillo activado** (viento, aforo, estructural, etc.).
3. **Valor del parametro objetivo** (anemometro a 45 km/h, densidad a 6.5 personas/m2, etc.).
4. **Identificacion del Director del PAU que firmo la suspension**.
5. **Hora de aviso al publico** por megafonia.
6. **Hora de inicio de la suspension** efectiva.
7. **Hora de finalizacion** (si se reanudo) o decision de cancelacion definitiva.
8. **Testigos** (jefe de seguridad, jefe de produccion, jefe medico).
9. **Firma del Director del PAU**.

#### Cadena de custodia

- Guardar el parte de suspension durante **minimo 5 anos** (plazo de prescripcion de la responsabilidad civil extracontractual).
- Si hay lesionados o fallecidos, guardar **indefinidamente** y entregar copia a la autoridad judicial.

---

## Bloque 8 - Como se comunica la suspension

### 8.1 Megafonia

#### Mensaje tipo

> "Atencion, atencion. Por motivos de seguridad relacionados con [causa concreta, sin alarmismo], les pedimos que se dirijan ordenadamente hacia las salidas laterales. Sigan las indicaciones del personal de seguridad. Gracias por su colaboracion."

#### Reglas

- Tono calmado, firme, sin gritos.
- Espanol + idioma local del evento + ingles basico si hay publico internacional.
- Repetir el mensaje cada 2 minutos durante la suspension.
- Evitar la palabra "evacuacion" si no hay riesgo vital real (puede provocar panico innecesario). Usar "desalojo ordenado" o "retirada temporal".

### 8.2 Personal de seguridad

- Cada vigilante tiene que conocer las vias de evacuacion.
- Cada vigilante tiene que llevar silbato (senales acusticas claras).
- Cada vigilante tiene que estar localizable por walkie (canal unico del evento).

### 8.3 Redes sociales

- Suspension comunicada por canales oficiales del evento (web, redes, app).
- Mensaje unico, sin contradicciones.
- No difundir rumores. No minimizar la situacion.

---

## Bloque 9 - Cuando NO hay gatilloAutomatico

Hay decisiones que NO sonAutomaticas. Requieren juicio del Director del PAU:

- Reanudacion del evento despues de una suspension temporal (criterios tecnicos del Director + tecnico de cada area).
- Cancelacion definitiva por causa menor acumulativa (varias incidencias pequenas).
- Suspension preventiva por causa etica (muerte de asistente en recinto no relacionada con el evento).

En estos casos, el Director del PAU decide, documenta y justifica. Pero NO delibera bajo presion economica. La decision final es tecnica, no comercial.

---

## Bloque 10 - Proteccion juridica del Director del PAU

### 10.1 Cobertura de la decision

El Director del PAU esta protegido juridicamente cuando:

- Aplica los gatillosAutomaticos de esta guia sin demora.
- Documenta la decision con el parte de suspension.
- Mantiene la cadena de mando intacta (sin injerencias del promotor, artista o productor).

### 10.2 Riesgos juridicos

El Director del PAU esta expuesto cuando:

- Aplica un gatilloAutomatico tarde (con parametro ya superado de forma evidente).
- NO aplica un gatilloAutomatico que estaba activado.
- Aplica una suspension arbitraria que causa danos economicos al promotor sin causa tecnica.

### 10.3 Recomendacion final

Tener un seguro de defensa juridica personal. La poliza de RC de la empresa cubre la responsabilidad civil, pero NO cubre los honorarios de abogado para defenderte penalmente. El seguro de defensa juridica personal te protege a ti, no a la empresa.

---

## Resumen ejecutivo: los 12 gatillosAutomaticos clave

| # | Gatillo | Umbral | Accion |
|---|---------|--------|--------|
| 1 | Viento sostenido en aire libre con estructuras | >30 km/h | Aviso + suspension temporal |
| 2 | Viento sostenido en aire libre sin estructuras | >40 km/h | Aviso + suspension temporal |
| 3 | Actividad electrica a <8 km | 1 rayo en 30 min | Suspension total |
| 4 | Densidad instantanea | >6 pers/m2 | Suspension temporal |
| 5 | Tiempo medio en cola de servicios | >45 min | Suspension total |
| 6 | Senales de avalancha | Cualquiera | Suspension total inmediata |
| 7 | Fallo estructural visible | Cualquiera | Evacuacion de la zona |
| 8 | Fallo de megafonia | Cualquiera | Suspension temporal |
| 9 | Arma blanca o de fuego detectada | Cualquiera | Suspension total + 112 |
| 10 | Orden FCSE / judicial / administrativa | Cualquiera | Suspension total |
| 11 | Victima mortal | Cualquiera | Suspension total |
| 12 | Sospecha NRBQ (>20 personas mismo sintoma en 30 min) | Cualquiera | Suspension total + 112 |

Imprime esta tabla. Plastificala. Pegala en el puesto del Director del PAU el dia del evento.

---

## Aviso

Esta guia es orientacion operativa, NO sustituye al PAU firmado por un tecnico competente ni al asesoramiento juridico de un abogado especializado en espectaculos publicos. Los umbrales son referencias operativas consensuadas por el sector, pero cada evento tiene circunstancias unicas que pueden requerir umbrales mas estrictos.

---

(C) 2026 Eduardo J. Lopez A.
Manual de Seguridad, Prevencion y Planes de Autoproteccion en Eventos y Espectaculos
Licencia CC BY-NC 4.0