# Guia 05 - Cumplimiento por comunidad autonoma

## Para que sirve esta guia

El Estado tiene una ley de espectaculos (Ley 17/1997) y un reglamento general (RD 2816/1982). Pero cada CCAA ha legislado con su propio ritmo, con sus particularidades, plazos y exigencias. Esta guia resume las 17 CCAA + 2 ciudades autonomas con lo que necesitas saber para cada una.

## Matriz resumen de capitales minimos de RC y plazos

| CCAA | Ley principal | Plazo solicitud | Capital base RC | Servicios medicos obligatorios |
|---|---|---|---|---|
| Andalucia | Ley 13/1999 | 30 dias | Decreto 109/2005 (especifico) | desde 1.000 personas |
| Aragon | Ley 11/2005 | 30 dias | 600.000 EUR | desde 500 cerrado / 2.000 abierto |
| Asturias | Ley 8/2002 | 1 mes / 48 h DR | 600.000 EUR | desde 1.000 personas |
| Baleares | Ley 8/2012 (turismo) | 30 dias | 600.000 EUR | desde 1.000 personas |
| Canarias | Ley 7/2011 (deroga 1/1998 desde 15-oct-2011) | 30 dias | 600.000 EUR | desde 1.000 personas |
| Cantabria | Ley 3/2017 + Ley 7/2020 + Decreto 157/2019 | 30 dias | Decreto 157/2019 (especifico) | desde 1.000 personas |
| Castilla-La Mancha | Ley 7/2011 (vigente hasta 7-ene-2027) → Ley 6/2026 desde 8-ene-2027 | 30 dias | estatal supletorio | desde 1.000 personas |
| Castilla y Leon | Ley 7/2006 + Decreto-ley 8/2020 | 30 dias | estatal supletorio | desde 1.000 personas |
| Cataluna | Ley 11/2009 + Decreto 112/2010 | 1 mes | 600.000 EUR | desde 500 cerrado / 2.000 abierto |
| C. Valenciana | Ley 14/2010 + Ley 7/2019 + Decreto 26/2019 | 30 dias | 600.000 EUR | desde 500 cerrado / 5.000 abierto |
| Extremadura | Ley 7/2019 + Decreto 66/2022 + Decreto 67/2022 | 30 dias naturales | estatal supletorio | desde 1.000 personas |
| Galicia | Ley 10/2017 + Decreto 124/2019 | 30 dias | estatal supletorio | DESDE EL PRIMER ASISTENTE |
| La Rioja | Ley 4/2000 (NO Ley 2/2002, que era de Salud) | 30 dias | estatal supletorio | desde 1.000 personas |
| Madrid | Ley 17/1997 (estatal) + OLDRUAM 6/2022 + Protocolo 24-10-2024 | 30 dias | estatal supletorio | desde 1.000 personas (recomendado) |
| Murcia | Ley 2/2003 + Ley 2/2017 (DA 8a) | 15 dias (51-150) / 30 dias (>150) | estatal supletorio | desde 1.000 personas |
| Navarra | Ley Foral 2/1989 + Ley Foral 5/2025 | 30 dias | estatal supletorio | desde 1.000 personas |
| Pais Vasco | Ley 4/1995 + Decreto 213/2012 + art. 35 bis | 30 dias | estatal supletorio | desde 1.000 personas |
| Ceuta | Ley 17/1997 (estatal supletoria) | 30 dias | estatal supletorio | desde 500 personas |
| Melilla | Ley 17/1997 (estatal supletoria) | 30 dias | estatal supletorio | desde 500 personas |

## Las 5 particularidades autonomicas mas criticas

### 1. Galicia: servicios medicos obligatorios desde el primer asistente

Ley 10/2017, art. sobre servicios de asistencia sanitaria. Es la CCAA mas exigente del Estado en este punto. Para un evento de 2.500 personas en Galicia: 2 medicos + 2 ambulancias. Para 5.000 personas: 4 medicos + 4 ambulancias.

La Xunta no perdona festivales sin medico. Si operas en Galicia, presupuesta el dispositivo medico desde el primer asistente.

Ademas: la Ley 10/2017 + Decreto 124/2019 establecen requisitos especificos para eventos en playas y paseos maritimos (informe de Costas de Galicia).

### 2. Madrid: Plan de Movilidad + Plan de Multitudes obligatorios

OLDRUAM 6/2022 + Protocolo de la Agencia de Actividades de 24-oct-2024. Cualquier evento al aire libre con mas de 1.000 personas necesita:

- Plan de Movilidad del Evento (con cortes de trafico, accesos de emergencia, transporte publico).
- Plan de Gestion de Multitudes (con criterios de densidad, evacuacion y gestion de flujo).
- Coordinacion con 112 / SUMMA.

La regla 4 personas/m2 al aire libre es la que mas se respeta en Espana porque Madrid la tiene escrita en su normativa. Si vendes mas entradas de las que caben segun 4 pers/m2, tienes problema serio (Madrid Arena 2012).

### 3. Cataluna: limite de 12 eventos anuales por sitio fijo

Decreto 112/2010, Anexo I, apartado V. Si organizas 13 eventos al ano en tu masia, el decimotercero requiere justificacion tecnica adicional. Esto es una carga para los promotores pequenos que usan el mismo sitio cada fin de semana.

Ademas: la Ley 11/2009 integra el Sistema de Emergencias Medicas (SEM) en el dispositivo. La coordinacion con el SEM es obligatoria para eventos grandes.

### 4. Pais Vasco: articulo 35 bis para suspension acustica

Decreto 213/2012, art. 35 bis. Las Administraciones Publicas vascas pueden autorizar temporalmente la suspension del cumplimiento de los limites acusticos por eventos de proyeccion social, cultural, deportiva, religiosa o análoga. Previa valoracion de la incidencia acustica y comunicacion a los afectados.

Implicacion: para un festival nocturno en zona residencial en Euskadi, el articulo 35 bis es tu amigo. Pides la suspension temporal, el Ayuntamiento te la concede, y tienes cobertura legal para superar los limites acusticos ordinarios. Pero ojo: tienes que hacer estudio acustico firmado por tecnico y comunicacion a los vecinos por carta con acuse de recibo.

### 5. Canarias: doble intervencion Cabildo + Ayuntamiento

Ley 7/2011, art. sobre eventos que cruzan mas de un municipio. En Canarias, la autorizacion inter-municipal dentro de la misma isla corresponde al Cabildo Insular, no al Gobierno de Canarias. La doble intervencion (Cabildo + Ayto) es critica.

Ademas: cada Cabildo Insular (7 islas, 7 Cabildos) puede tener normativa insular complementaria. Consulta con el Cabildo de Tenerife, Gran Canaria, Fuerteventura, Lanzarote, La Palma, La Gomera o El Hierro segun corresponda.

## Casos donde la legislacion autonoma es mas laxa que la estatal

- **Murcia**: tres tramos claros (≤50 sin DR, 51-150 DR, >150 autorizacion). Es la CCAA mas clara en cuanto a umbrales. La Sede electronica CARM tiene modelos pre-formateados.
- **Baleares**: el regimen depende del Consell Insular (Mallorca, Menorca, Eivissa, Formentera). Lo que funciona en Mallorca NO funciona igual en Eivissa.
- **Aragon**: el regimen aplicable depende del aforo (en INAGA, Instituto Aragones de Gestion Ambiental, para espacios naturales protegidos).

## Casos donde la legislacion autonoma es mas estricta que la estatal

- **Galicia** (servicios medicos desde el primer asistente)
- **Madrid** (Plan de Movilidad + Plan de Multitudes)
- **Andalucia** (Decreto 109/2005 sobre capitales de RC, mas especifico que la ley estatal)
- **Cantabria** (Decreto 157/2019 sobre capitales de RC, con tramos especificos)

## Cambios normativos recientes que debes verificar

| Norma | Cambio | Fecha de aplicacion |
|---|---|---|
| RD 524/2023 | Deroga el RD 393/2007 (PAU) | Junio 2023 |
| RD 607/2026 | Deroga el RD 1435/1985 (RGEEAA) | 25 de mayo de 2027 |
| Reglamento UE 2023/1230 | Deroga la Directiva 2006/42/CE sobre maquinas | 20 de enero de 2027 |
| Ley 6/2026 CLM | Deroga la Ley 7/2011 de Castilla-La Mancha | 8 de enero de 2027 |
| Ley Foral 5/2025 | Modifica la Ley Foral 2/1989 de Navarra | Abril 2025 |

## Como verificar la normativa vigente de tu CCAA

1. **Sede electronica de tu CCAA**: busca la Direccion General competente en espectaculos.
2. **BOE consolidado**: para verificar si hay modificaciones estatales.
3. **Tu abogado**: el unico que puede decirte con garantia que aplica a tu caso concreto.

Antes de presentar documentacion a la Administracion, valida siempre con la sede electronica. La legislacion cambia y el estado de hoy puede no ser el de dentro de 6 meses.

---

(C) 2026 Eduardo J. Lopez A.
Licencia CC BY-NC 4.0
