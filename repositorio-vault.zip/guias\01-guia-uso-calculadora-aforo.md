# Guia 01 - Como usar la calculadora de aforo (plantilla 12)

## Para que sirve esta guia

La calculadora de aforo es la unica plantilla del Repositorio con formulas automaticas. Te calcula el aforo maximo que puedes vender sin exponerte a responsabilidad penal, aplicando el metodo del CTE DB-SI 3 con los criterios del Protocolo de la Agencia de Actividades de Madrid de 24 de octubre de 2024.

Esta guia te explica paso a paso como rellenarla correctamente.

## Cuando usar la calculadora

Usa la calculadora en tres momentos:

1. **30-60 dias antes del evento**: para dimensionar la documentacion (memoria de actividad, PAU, plan de multitudes si Madrid > 1.000 al aire libre).
2. **15 dias antes del evento**: para verificar que no ha cambiado nada que afecte al aforo (cierre de una salida, aumento de aforamiento publico esperado, etc.).
3. **El dia del evento, 60-90 minutos antes**: para confirmar el aforo definitivo y archivarlo con el acta.

## Que necesitas antes de empezar

Antes de abrir la calculadora, ten a mano:

- **Licencia de actividad del local** (si el evento es en interior) o **autorización municipal del evento** (si es al aire libre o en local con cambio de uso). Necesitas el **aforo legal** que figura en esa documentacion.
- **Plano del recinto** con las salidas de emergencia marcadas, su anchura en metros, y la distancia maxima de cualquier punto del publico a la salida mas cercana.
- **Prevision meteorologica** (si es al aire libre) porque el viento y la lluvia pueden afectar al aforo util calculado.
- **Prevision de publico asistente** (porcentaje de jovenes, presencia de PMR, etc.).

## Paso 1 - Rellenar los datos de entrada (filas 5-19)

### Superficie util del recinto (m2)

Como regla practica:
- **Suma** toda la superficie accesible al publico asistente: pista, gradas, barras atendidas por personal del lado del publico, terrazas, etc.
- **NO sumes**: escenario, camerinos, almacenes, barra del personal, zona de carga y descarga, pasillos de evacuacion si ya estan descontados de la superficie util del local.

Si el recinto es de forma irregular, dividelo en rectangulos y triangulos, calcula el area de cada uno y suma. La mayoria de recintos tienen su superficie en el plano municipal. Si no la tienes, pedila al propietario o al tecnico municipal.

**Dato de partida habitual**: una sala de conciertos mediana tiene entre 500 y 1.500 m2. Un festival al aire libre en una explanada, entre 5.000 y 50.000 m2.

### Densidad maxima operativa (personas/m2)

Es el dato MAS critico. Lo determina tu CCAA y el tipo de recinto:

| Tipo de recinto | Densidad maxima | Norma |
|---|---|---|
| Aire libre, espacio abierto | 4 personas/m2 | Madrid OLDRUAM art. 58.7 |
| Aire libre, controlado (vallas perimetrales) | 2-3 personas/m2 | CTE DB-SI 3 |
| Interior, sala con escenario fijo | 2-3 personas/m2 | CTE DB-SI 3 |
| Interior, sala multiusos | 2 personas/m2 | CTE DB-SI 3 |
| Graderio con asiento fijo | 1 persona por plaza | CTE DB-SI 3 |
| Recinto historico con vias estrechas | 0,5-1 persona/m2 | Casos CCAA |
| Galicia, cualquier evento al aire libre | seguir estatal + Decreto 124/2019 | Xunta |

**Error tipico**: usar 4 personas/m2 en un graderio. NO. El graderio es 1 persona por plaza. La diferencia es brutal: 1.000 plazas de graderio son 1.000 personas maximo, no 4.000.

### Numero de salidas de emergencia y anchura total

Cuenta solo las salidas de emergencia UTILIZABLES durante el evento, no las salidas de personal o de servicio.

- **Anchura minima de cada salida**: 0,80 m. Si alguna salida es menor, la calculadora te avisara con una alerta.
- **Modular a 0,60 m adicionales**: si tienes una salida de 1,40 m, computa como 1,20 m utiles (dos modulos de 0,60 m).
- **Formula del CTE DB-SI 3**: 1 metro de salida = 200 personas como maximo aforo evacuable.

### Personas por minuto por metro

Este valor es **constante = 100**. Esta fijado por el CTE DB-SI 3. Es la velocidad maxima razonable de evacuacion humana en una salida libre de obstaculos. Si tus salidas tienen obstaculos (mostradores cerca, angulos cerrados, escalones), bajalo a 80 o 70.

### Tiempo maximo de evacuacion

| Riesgo del recinto | Tiempo maximo |
|---|---|
| Bajo (aire libre, vias amplias, salidas distribuidas) | 8 minutos |
| Medio (recinto cerrado 1.000-5.000 personas) | 6 minutos |
| Alto (recinto cerrado >5.000 personas o distribucion dificil) | 2,5 minutos |

### Distancia maxima a salida

- **Interior con rociadores automaticos**: 50 m.
- **Interior sin rociadores**: 35 m.
- **Al aire libre**: hasta 60 m, segun calculo.

Si tienes un punto del recinto a 70 m de la salida mas cercana, la calculadora te dira que ese punto esta fuera de norma. O reduces el aforo de esa zona, o abres una salida adicional.

### Aforo legal (segun licencia)

Dato que sale de tu licencia de actividad o de la autorizacion del evento. Es el techo legal, inamovible. No se puede vender por encima.

### Entradas vendidas

Numero de tickets emitidos o entradas puestas a la venta. No puede superar al menor del legal o util. Si vendes mas, ya sabes lo que pasa (Madrid Arena 2012, 4 anos de carcel).

### Personas con movilidad reducida, sensoriales, TEA

Datos estimativos para dimensionar plazas reservadas, aseos adaptados, zona de baja estimulacion, bucle magnetico, etc. Aunque no afecten al calculo del aforo, son obligatorios por ley (Ley General de Discapacidad).

## Paso 2 - Leer los calculos automaticos (filas 22-25)

La calculadora genera cuatro resultados. **Solo el cuarto es el que firmas**.

### Aforo de evacuacion (densidad)

Es la superficie util multiplicada por la densidad maxima. Te dice el aforo maximo permitido por concentracion fisica del publico.

### Aforo de evacuacion (tiempo)

Es el numero de salidas por la anchura total por 100 personas/min/m por el tiempo maximo. Te dice el aforo maximo permitido por capacidad de salida.

### Aforo de evacuacion (menor)

Es el menor de los dos anteriores. Es el aforo util maximo posible segun el recinto fisico.

### AFORO FINAL (el que se firma)

Es el menor entre: aforo legal, aforo util menor, y entradas vendidas. **Este es el numero que aparece en todos tus documentos oficiales**.

## Paso 3 - Interpretar las alertas (filas 28-32)

La calculadora tiene cinco alertas automaticas. Cada una te dice si hay un problema critico:

| Alerta | Que significa |
|---|---|
| Sobreaforo | Estas vendiendo mas entradas de las que caben |
| Sin salidas | Tu recinto no tiene salidas de emergencia definidas |
| Anchura insuficiente | Alguna salida es menor de 0,80 m |
| Densidad no estandar | La densidad maxima supera 4 personas/m2 |
| Tiempo excesivo | El tiempo de evacuacion es mayor de 8 min |

**Si cualquier alerta dice ALERTA, no firmes la documentacion todavia.** Resuelve primero el problema.

## Caso practico: festival al aire libre en una explanada de 2.500 m2

**Datos de entrada:**
- Superficie util: 2.500 m2
- Densidad: 4 pers/m2 (aire libre)
- Salidas: 4
- Anchura total: 8 m (4 salidas x 2 m cada una)
- Tiempo: 8 min (bajo riesgo)
- Aforo legal: 5.000 (segun autorizacion municipal)
- Entradas vendidas: 6.000 (has vendido mas de lo que dice la licencia)

**Calculos:**
- Aforo por densidad: 2.500 x 4 = 10.000 personas
- Aforo por tiempo: 4 x 8 x 100 x 8 = 25.600 personas
- Aforo util menor: MIN(10.000, 25.600) = 10.000 personas
- AFORO FINAL: MIN(5.000, 10.000, 6.000) = **5.000 personas**
- Alerta sobreaforo: **ALERTA: vender menos o ampliar aforo** (porque 6.000 > 5.000)

**Conclusion operativa:** tienes que dejar sin vender 1.000 entradas o reducir el aforo vendido a 5.000. Si no lo haces y el evento tiene un incidente, la responsabilidad penal es tuya.

## Que hacer despues de calcular

1. **Imprime la hoja de calculo** con los datos y los resultados firmados por el Director del PAU.
2. **Adjuntala al PAU** firmado por el tecnico competente.
3. **Archivala junto al acta del evento** una vez finalizado.
4. **Si hay alertas en rojo**, no firmes todavia. Resuelve primero el problema (ampliar salidas, reducir aforo, etc.).

## Errores frecuentes

1. **Contar las salidas de personal como salidas de emergencia**: no. Las salidas de personal computan para evacuacion de trabajadores, no para evacuacion de publico asistente.
2. **Usar la densidad del aire libre (4) en interior**: en interior, 2-3. La diferencia entre 4 y 2 es la mitad del aforo.
3. **Olvidar restar la superficie del escenario**: si tienes un escenario de 100 m2 dentro de una sala de 1.000 m2, la superficie util es 900, no 1.000.
4. **Olvidar la anchura minima de 0,80 m**: si una salida es de 0,60 m (por ejemplo, una puerta de servicio), NO cuenta como salida de emergencia.
5. **Asumir que el aforo legal es siempre el techo**: el aforo util calculado por la calculadora puede ser MENOR que el aforo legal. En ese caso, el aforo final es el util, no el legal.

## Cuando la calculadora NO basta

La calculadora es una herramienta de calculo. NO sustituye:

- **El PAU firmado por un tecnico competente** que ha visitado el recinto.
- **La memoria de actividad visada** si tu CCAA lo exige.
- **La verificacion in situ** el dia del evento (recorrido de las salidas, prueba de iluminacion de emergencia, etc.).
- **El visto bueno del Ayuntamiento** con la autorizacion firmada.

La calculadora te da el numero. El resto del proceso es el que hace que ese numero sea defendible ante un juez, una aseguradora o un inspector.

---

(C) 2026 Eduardo J. Lopez A.
Licencia CC BY-NC 4.0
