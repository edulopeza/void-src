# Guia 04 - Que plantilla uso para cada tipo de evento

## Para que sirve esta guia

El Repositorio tiene 12 plantillas. No todas son necesarias para todos los eventos. Esta guia te ayuda a identificar que documentos necesitas segun el tipo de actividad, el aforo y la CCAA.

## Arbol de decision rapido

```
¿Tu evento es un espectaculo publico con autorizacion o DR?
  SI -> Necesitas PAU (plantilla 03) + Memoria de actividad (plantilla 04) + Poliza RC
  NO -> ¿Tiene algun riesgo especial?
    SI -> Ver tabla de riesgos especiales
    NO -> ¿Tienes > 500 personas?
      SI -> PAU + poliza + checklist pre-apertura (plantilla 01)
      NO -> Checklist basico + seguro de RC de la actividad habitual
```

## Plantillas obligatorias (todos los eventos de espectaculo publico)

Estas las necesitas SIEMPRE que organices un evento con autorizacion o DR municipal o autonoma:

| Plantilla | Cuando la uso |
|---|---|
| 01 - Checklist Pre-Apertura | 60-90 minutos antes de la apertura de puertas. La firma el Director del PAU. |
| 02 - Checklist Cierre | Inmediatamente despues de terminado el evento. La firma el Director del PAU. |
| 03 - PAU Express | 30-60 dias antes. Lo firma el tecnico competente. Se entrega con la solicitud de licencia. |
| 04 - Memoria de Actividad | 30-60 dias antes. La firma el tecnico. Se entrega con la solicitud de licencia. |
| 05 - Briefing Pre-Evento | 30 minutos antes de la apertura. Lo firma el Director del PAU. |
| 06 - Acta de Coordinacion con Servicios Externos | 15-30 dias antes. La firman todas las partes (promotor, seguridad, ambulancias, hospital). |
| 12 - Calculadora de Aforo Util | Tres veces: 30-60 dias antes, 15 dias antes, y 60-90 minutos antes. La firma el Director del PAU. |

## Plantillas por riesgo especial

Ademas de las obligatorias, usa estas segun los elementos tecnicos de tu evento:

| Si tu evento tiene... | Usa plantilla... |
|---|---|
| Pirotecnia T1 (bengala, fuente fria de bajo riesgo) | 07 - Pirotecnia T1/T2 + anexo de pirotecnia en la poliza RC |
| Pirotecnia T2 (cold spark, fuente con llama, chispas controladas) | 07 - Piroteccia T1/T2 + certificado de artillero pirotécnico + autorizacion Subdelegacion + anexo poliza |
| Pirotecnia F3 / F4 (cohetes, castillos, truenos cinematograficos) | 07 - Pirotecnia T1/T2 + proyecto tecnico firmado + inspeccion previa + deposito |
| Láser clase 3B o 4 | 08 - Láser LSO + DNRO + designacion del LSO + calculo de DNRO + distancias verificadas |
| Maquina de humo (glycol) o niebla baja (CO2) | 09 - Hazer / Niebla / CO2 / LN2 + SDS del fluido + sensor de O2 si CO2 o LN2 |
| Liquid nitrogen (LN2) | 09 - Hazer / Niebla / CO2 / LN2 + sensor de O2 + plan de emergencia ante derrame |
| Cold spark | 10 - Cold Spark + marcado CE de maquina y cargas + anexo poliza T2 |
| Drones (UAS) | 11 - Drones UAS + autorizacion AESA + seguro especifico + NOTAM a aviacion civil |
| Norias / carruseles / hinchables / camas elasticas | Contrato con la empresa de atracciones + seguro especifico + revision anual de la atraccion + clausula de velocidad |

## Por tipo de evento especifico

### Concierto en sala (interior, 200-2.000 personas)

- Obligatorias: 01, 02, 03, 04, 05, 06, 12
- Riesgos especiales: solo si hay pirotecnia, láser o hazer
- Calculadora de aforo: clave. La sala tiene aforo legal estricto (placa municipal).

### Festival al aire libre (mas de 1.000 personas)

- Obligatorias: 01, 02, 03, 04, 05, 06, 12
- Riesgos especiales: casi siempre hay hazer, posiblemente pirotecnia, posiblemente cold spark, posiblemente drones
- Madrid > 1.000 al aire libre: Plan de Movilidad + Plan de Multitudes obligatorio
- Galicia: dispositivo medico obligatorio desde el primer asistente (Ley 10/2017)

### Boda con gran aforo (200-500 personas en finca rustica o pabellon)

- Obligatorias: 01, 02, 03 (si la CCAA lo exige), 04, 12
- Poliza: mas simple, pero verifica que cubre eventos privados
- Riesgos especiales: solo si hay pirotecnia, DJs con láser, etc.

### Feria comercial (mas de 500 personas)

- Obligatorias: 01, 02, 03, 04, 05, 06, 12
- Riesgos especiales: si hay atracciones de feria (plantilla 11 como referencia)
- Coordinacion con el Ayto: mas estricta por las vias publicas afectadas

### Evento corporativo (50-500 personas en local cerrado)

- Obligatorias: 01, 02, 05, 06, 12
- PAU: si aforo > 500 en local cerrado (la mayoria)
- Memoria de actividad: simplificada, del local
- Riesgos especiales: solo si hay elementos tecnicos especificos

### Partido de futbol / evento deportivo (mas de 1.000 personas)

- Obligatorias: todas, pero adaptadas al recinto deportivo
- Ademas: normativa especifica de la Liga, Federacion o Competicion
- Riesgos especiales: pirotecnia (bengalas en gradas), publico hostil

### Manifestacion / concentracion politica (mas de 500 personas)

- NO es un espectaculo publico: regimen especial de la Ley Organica 9/1983
- Comunicacion previa a la Delegacion del Gobierno
- Plan de seguridad especifico
- Coordinacion con Policia Nacional

## Por comunidad autonoma

Madrid:
- > 1.000 personas al aire libre: Plan de Movilidad + Plan de Multitudes (OLDRUAM 6/2022 + Protocolo 24-10-2024)
- Recintos cerrados > 5.000 personas: 4 años prisión para promotor por sobreaforo (TS 805/2017)

Cataluna:
- 12 eventos maximo al año en sitio fijo
- Sistema de Emergencias Medicas (SEM) integrado en el dispositivo
- Ley 11/2009 + Decreto 112/2010

Galicia:
- Servicio medico obligatorio desde el primer asistente (Ley 10/2017 + Decreto 124/2019)
- 1 medico + 1 ambulancia por cada 1.000 personas suplementarias

Andalucia:
- Decreto 109/2005 sobre capitales de RC
- Modelo oficial en sede electronica de la Junta

Valencia:
- Autorizacion municipal + informe ambiental si aforo > 5.000 al aire libre
- Ley 7/2002 de proteccion acustica

Pais Vasco:
- Articulo 35 bis del Decreto 213/2012: suspension temporal del limite acustico
- Comunicacion a vecinos por carta con acuse de recibo

## Resumen: cuantas plantillas uso

| Escenario | Total plantillas |
|---|---|
| Concierto en sala pequeno sin riesgos especiales | 7 (01-06, 12) |
| Festival medio al aire libre con pirotecnia + drones | 11 (01-09, 10, 11, 12) |
| Boda con 300 personas en pabellon | 4 (01, 02, 05, 12) |
| Gran festival > 5.000 personas con todos los elementos | 12 (todas) |

## Errores frecuentes

1. **Pensar que con el PAU ya esta todo**: no. El PAU es uno de los 7-12 documentos necesarios.
2. **No usar la calculadora de aforo porque "ya se el aforo"**: el dia que el Ayuntamiento te pida documentacion, el calculo firmado por el Director del PAU es lo que te salva.
3. **Olvidarse de las plantillas 05 (briefing) y 06 (acta de coordinacion)**: sin briefing, el dia del evento no hay nadie que sepa que pasa si hay un conato de incendio. Sin acta de coordinacion firmada, las ambulancias no saben donde aparcar.
4. **Rellenar el PAU 24 horas antes del evento**: el tecnico competente necesita 15-30 dias para hacer el analisis de riesgos, las visitas al recinto, la firma del director del PAU y la entrega al Ayuntamiento. Si lo haces el dia antes, no tienes PAU firmado.

---

(C) 2026 Eduardo J. Lopez A.
Licencia CC BY-NC 4.0
